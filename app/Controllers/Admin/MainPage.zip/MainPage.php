<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class MainPage extends BaseController
{

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        helper("util");
    }

    public function reorderDisplayOrder(
        string $table,
        string $primaryKey,
        int $currentId,
        int $newOrder,
        string $operation,
        string $isDeletedField = 'is_deleted'
    ): void {
        $builder = $this->db->table($table);
        $orderField = 'display_order';
        if ($operation === 'delete') {
            $row = $builder->where($primaryKey, $currentId)->get()->getRow();
            if (!$row)
                return;
            $deletedOrder = (int) $row->$orderField;
            $builder->set($orderField, "$orderField - 1", false)
                ->where($orderField . ' >', $deletedOrder)
                ->where("{$isDeletedField} !=", 1)
                ->update();
        } elseif ($operation === 'insert') {
            $builder->set($orderField, "$orderField + 1", false)
                ->where($orderField . ' >=', $newOrder)
                ->where("{$isDeletedField} !=", 1)
                ->update();
        } elseif ($operation === 'update') {
            $row = $builder->where($primaryKey, $currentId)->get()->getRow();
            if (!$row)
                return;

            $oldOrder = (int) $row->$orderField;

            if ($newOrder < $oldOrder) {
                $builder->set($orderField, "$orderField + 1", false)
                    ->where($orderField . ' >=', $newOrder)
                    ->where($orderField . ' <', $oldOrder)
                    ->where($primaryKey . ' !=', $currentId)
                    ->where("{$isDeletedField} !=", 1)
                    ->update();
            } elseif ($newOrder > $oldOrder) {
                $builder->set($orderField, "$orderField - 1", false)
                    ->where($orderField . ' <=', $newOrder)
                    ->where($orderField . ' >', $oldOrder)
                    ->where($primaryKey . ' !=', $currentId)
                    ->where("{$isDeletedField} !=", 1)
                    ->update();
            }
        }
    }

    //Menu
    public function pageMenu()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Menu";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Menu <i style="font-size:14px" class="fas fa-chevron-right"></i> <span> </span></div>';
        return view('admin/pages/menu', $page);
    }

    public function getMenu()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_menu')
            ->select('web_menu_id,web_title,web_url, 
            concat("' . MENU_IMG . '",web_image) as web_image,created_on,meta_title,meta_desc,meta_key,is_active')
            ->where('is_deleted', 0)
            ->where('web_menu_id !=', 1);
        if ($this->request->getPost('web_menu_id', NULL)) {
            $data->where('web_menu_id', $this->request->getPost('web_menu_id', NULL));
        }
        $data = $data->orderBy('web_menu_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);

        return $this->respond(data: $data, message: 'successfully');
    }

    public function saveMenu()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "edit":
                $manda_arr = ['web_menu_id'];
                $allowedFields = ['web_title', 'web_image', 'meta_title', 'meta_desc', 'meta_key', 'is_active'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/menu/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "menu_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_menu_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        if (isset($updateData['web_title']) && isset($data['web_menu_id']) && $data['web_menu_id'] != 1) {
            $updateData['web_url'] = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $updateData['web_title']), '-'));
        }

        $builder = $this->db->table('web_menu');

        if ($data['web_menu_id'] > 0) {

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_menu_id', $data['web_menu_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {
            return $this->respond($data, 'Unable to save Data', 404);
        }
        return $this->respond([], 'successfully');
    }

    //Home Page Meta Tags SEO
    public function pageHomeMeta()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Home Page Meta SEO";
        $page['data'] = $this->db->table('web_menu')
            ->select('meta_title, meta_desc, meta_key')
            ->where('web_menu_id', 1)
            ->get()->getRowArray();
        return view('admin/pages/home_meta', $page);
    }

    public function saveHomeMeta()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check format
        if (($data['for'] ?? '') !== "edit_home_meta") {
            return $this->respond([], "Missing Data 'for'", 404);
        }

        $allowedFields = ['meta_title', 'meta_desc', 'meta_key'];
        $updateData = array_intersect_key($data, array_flip($allowedFields));
        
        $this->db->table('web_menu')->where('web_menu_id', 1)->update($updateData);
        return $this->respond([], 'successfully');
    }

    //Setting
    public function pageSetting()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Setting";
        $page['data'] = $this->db->table('web_setting')
            ->select('*')
            ->where('web_setting_id', 1)
            ->get()->getRowArray();
        $page['breadcrumb'] = '<div class="own-breadcrumb">Contact Us <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Contact Us </span></div>';
        return view('admin/pages/setting', $page);
    }

    public function saveSetting()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();
        $data['web_setting_id'] = 1;
        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "edit":
                $manda_arr = [];
                $allowedFields = [
                     "about_content",
                    "social_title",
                    "facebook_url",
                    "x_url",
                    "instagram_url",
                    "linkedin_url",
                    "youtube_url",
                    "user_email",
                    "user_phone_1",
                    "user_phone_2",
                    "contentus_title",
                    "contentus_title_content",
                    "map_url",
                    "address_1",
                    "address_2",
                    "address_3",
                    "address_4",
                    "state",
                    "country",
                    "pincode",
                    "web_content_1",
                    "web_content_2",
                    "web_content_3",
                    "usa_address",
                    "usa_phone",
                    "usa_email",
                    "uae_address",
                    "uae_phone",
                    "uae_email",
                    "usa_flag",
                    "uae_flag"
                ];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }

        // File handling for flags
        $path = ROOTPATH . 'images/event/';
        if (!is_dir($path)) mkdir($path, 0755, true);

        $usa_flag = $this->request->getFile('usa_flag');
        if ($usa_flag && $usa_flag->isValid() && !$usa_flag->hasMoved()) {
            $newName = 'usa_flag_' . time() . '.' . $usa_flag->getExtension();
            $usa_flag->move($path, $newName);
            $data['usa_flag'] = $newName;
        }

        $uae_flag = $this->request->getFile('uae_flag');
        if ($uae_flag && $uae_flag->isValid() && !$uae_flag->hasMoved()) {
            $newName = 'uae_flag_' . time() . '.' . $uae_flag->getExtension();
            $uae_flag->move($path, $newName);
            $data['uae_flag'] = $newName;
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_setting');
        if ($data['web_setting_id'] > 0) {
            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_setting_id', $data['web_setting_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {
            return $this->respond($data, 'Unable to save Data', 404);
        }
        return $this->respond([], 'successfully');
    }

    //SMTP Setting
    public function pageSmtp()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "SMTP Setting";
        $page['data'] = $this->db->table('web_smtp')
            ->select('*')
            ->where('web_smtp_id', 1)
            ->get()->getRowArray();
        $page['breadcrumb'] = '<div class="own-breadcrumb">SMTP<i style="font-size:14px" class="fas fa-chevron-right"></i> <span>SMTP Setting </span></div>';
        return view('admin/pages/smtp', $page);
    }

    public function saveSmtp()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();
        $data['web_smtp_id'] = 1;
        // Check Mandatory Fields
        switch ($data['for'] ?? '') {
            case "edit":
                $manda_arr = [];
                $allowedFields = [
                    "web_host_mail",
                    "wweb_user_mail",
                    "web_pass",
                    "web_port",
                    "web_crypto",
                    "web_to_mail"
                ];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_smtp');
        if ($data['web_smtp_id'] > 0) {
            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_smtp_id', $data['web_smtp_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {
            return $this->respond($data, 'Unable to save Data', 404);
        }
        return $this->respond([], 'successfully');
    }

    //Banner
      public function pageBanner() {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Banner";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Banner </span></div>';
        
        // Fetch menus for the button_url select
        $page['menus'] = $this->db->table('web_menu')
            ->select('web_menu_id, web_title, web_url')
            ->where('is_deleted', 0)
            ->where('is_active', 1)
            ->get()->getResultArray();
            
        // Fetch services for the button_url select
        $page['services'] = $this->db->table('web_service')
            ->select('web_service_id, web_title, web_url')
            ->where('is_deleted', 0)
            ->where('is_active', 1)
            ->orderBy('display_order', 'ASC')
            ->get()->getResultArray();
            
        return view('admin/pages/banner', $page);
    }

    public function getBanner() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_banner')
                ->select('web_banner_id,
            web_title,
            web_content,
            web_description, 
            concat("' . BANNER_IMG . '",web_image) as web_image,
            display_order,
            created_on,
            is_active,
            button_url')
                ->where('is_deleted', 0);
        if ($this->request->getPost('web_banner_id', NULL)) {
            $data->where('web_banner_id', $this->request->getPost('web_banner_id', NULL));
        }
        $data = $data->orderBy('web_banner_id')
                        ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);

        $data_count = $this->db->table('web_banner')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveBanner() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fields
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_banner_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                        table: 'web_banner',
                        primaryKey: 'web_banner_id',
                        currentId: $data['web_banner_id'],
                        newOrder: 0,
                        operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_banner_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $manda_arr = ['web_banner_id'];
                // Add 'button_url' field (the slug/url for the banner button)
                $allowedFields = ['web_title', 'web_content', 'web_image', 'display_order', 'web_description', 'button_url'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/banner/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "banner_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_banner_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_banner');

        if ($data['web_banner_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                        table: 'web_banner',
                        primaryKey: 'web_banner_id',
                        currentId: $data['web_banner_id'],
                        newOrder: $data['display_order'],
                        operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_banner_id', $data['web_banner_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                    table: 'web_banner',
                    primaryKey: 'web_banner_id',
                    currentId: $data['web_banner_id'],
                    newOrder: $data['display_order'],
                    operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

//enable ||disable function 
        public function pagefunctionmanage()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
           $data = $this->request->getPost();

          $web_content_id = $data['web_content_id'];
          $is_active = $data['is_active'];

           $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
            ->where('web_content_id',$web_content_id)
            ->get()->getRowArray();
            $builder = $this->db->table('web_content');

            $updateData['status'] = $is_active;
            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_content_id', $web_content_id);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
            return $this->respond([], 'successfully');

    }

    // Home Page About
    public function pageAboutAbout()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
            ->where('web_content_id', 1)
            ->get()->getRowArray();

        $page['title'] = "Home";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>About</span></div>';
        return view('admin/pages/aboutcontent', $page);
    }

    // Home our services
    public function pageAboutOurBusiness()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        

        $page['title'] = "Home Our Services";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Our Services</span></div>';
        $page['data'] = $this->db->table('web_business')
            ->select('web_business_id, web_title, web_content, CONCAT("' . BUSINESS_IMG . '", web_image) as web_image, display_order, created_on, is_active')
            ->where('is_deleted', 0)
            ->orderBy('display_order')
            ->get()->getResultArray();

            $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 2)
            ->get()->getRowArray();
        // $page['title'] = "About";
        // $page['breadcrumb'] = '<div class="own-breadcrumb">About Our Industry <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Content</span></div>';
        return view('admin/pages/homeservices', $page);
    }

public function getAboutOurBusiness()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }

    $data = $this->db->table('web_business')
        ->select('web_business_id, web_title, CONCAT("' . BUSINESS_IMG . '", web_image) as web_image, display_order, created_on, is_active')
        ->where('is_deleted', 0);

    if ($this->request->getPost('web_business_id', NULL)) {
        $data->where('web_business_id', $this->request->getPost('web_business_id', NULL));
    }
    $data = $data->orderBy('web_business_id')->get()->getResultArray();

    foreach ($data as $i => &$row) {
        $row['serial_no'] = $i + 1;
    }
    unset($row);

    $data_count = $this->db->table('web_business')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

    return $this->respond(
        data: $data,
        message: 'successfully',
        last_count: ($data_count['data_count'] ?? 1)
    );
}

public function saveAboutOurBusiness()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }
    $db = \Config\Database::connect();
    $data = $this->request->getPost();
    $action = $data['for'] ?? '';
    $isNew  = ($data['web_business_id'] == -1);
    $builder = $db->table('web_business');

    // Handle Image Upload First
    $uploadedImage = null;
    $file = $this->request->getFile('web_image');
    if ($file && $file->isValid() && !$file->hasMoved()) {
        $uploadPath = ROOTPATH . 'images/business/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }
        $newName = 'business_' . time() . '_' . rand(1000, 9999) . '.' . $file->getClientExtension();
        if ($file->move($uploadPath, $newName)) {
            $uploadedImage = $newName;
        } else {
            return $this->respond([], 'Failed to upload image', 500);
        }
    }

    switch ($action) {
        case 'delete':
            if (empty($data['web_business_id'])) {
                return $this->respond([], 'ID required', 400);
            }

            $this->reorderDisplayOrder(
                table: 'web_business',
                primaryKey: 'web_business_id',
                currentId: $data['web_business_id'],
                newOrder: 0,
                operation: 'delete'
            );

            $builder->where('web_business_id', $data['web_business_id'])
                    ->update(['is_deleted' => 1]);
            break;

        case 'status':
            if (empty($data['web_business_id']) || !isset($data['is_active'])) {
                return $this->respond([], 'Invalid status', 400);
            }

            $builder->where('web_business_id', $data['web_business_id'])
                    ->update(['is_active' => $data['is_active'] ? 1 : 0]);
            break;

        case 'edit':
            // Required fields: Title and Display Order only. Content is NOT required.
            if (empty($data['web_title']) || !isset($data['display_order'])) {
                return $this->respond([], 'Title and Display Order are required', 400);
            }

            if ($isNew && !$uploadedImage) {
                return $this->respond([], 'Image is required when adding new item', 400);
            }

            $saveData = [
                'web_title'     => trim($data['web_title']),
                'display_order' => (int)$data['display_order'],
            ];

            // Only set web_content if it's set in the data
            if (isset($data['web_content'])) {
                $saveData['web_content'] = $data['web_content'];
            }

            if ($uploadedImage) {
                $saveData['web_image'] = $uploadedImage;
            }

            if ($isNew) {
                // INSERT NEW
                $this->reorderDisplayOrder(
                    table: 'web_business',
                    primaryKey: 'web_business_id',
                    currentId: 0,
                    newOrder: $saveData['display_order'],
                    operation: 'insert'
                );

                $saveData['is_active']   = 1;
                $saveData['is_deleted']  = 0;
                $saveData['created_at']  = date('Y-m-d H:i:s');

                $builder->insert($saveData);
            } else {
                // UPDATE EXISTING
                $this->reorderDisplayOrder(
                    table: 'web_business',
                    primaryKey: 'web_business_id',
                    currentId: $data['web_business_id'],
                    newOrder: $saveData['display_order'],
                    operation: 'update'
                );

                $saveData['updated_at'] = date('Y-m-d H:i:s');

                $builder->where('web_business_id', $data['web_business_id'])
                        ->update($saveData);
            }
            break;

        default:
            return $this->respond([], 'Invalid action', 400);
    }

    return $this->respond([], 'successfully');
}

// page home industry

public function pageAboutOurIndustry()
{
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    

    // $page['title'] = " Our offer ";
    // $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span> our offer</span></div>';
    $page['data'] = $this->db->table('web_industry')
        ->select('web_industry_id, web_title,CONCAT("' . INDUSTRY_IMG . '", web_image) as web_image, display_order, created_on, is_active')
        ->where('is_deleted', 0)
        ->orderBy('display_order')
        ->get()->getResultArray();
        
        $page['data'] = $this->db->table('web_content')
        ->select('*')
        ->where('web_content_id', 3)
        ->get()->getRowArray();
    $page['title'] = "Home Our Industry";
    $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Our Industry</span></div>';

    return view('admin/pages/ouroffer', $page);
}

// AJAX - Get About Our Business Data
// <?php

// Add these methods to the MainPage controller class in MainPage.php

public function getAboutOurIndustry()
{
if (!session()->get('user_login_id')) {
    return $this->respond([], 'Session Expired', 404);
}

$data = $this->db->table('web_industry')
    ->select('web_industry_id, web_title, CONCAT("' . INDUSTRY_IMG . '", web_image) as web_image, web_content,display_order, created_on, is_active')
    ->where('is_deleted', 0);

if ($this->request->getPost('web_industry_id', NULL)) {
    $data->where('web_industry_id', $this->request->getPost('web_industry_id', NULL));
}
$data = $data->orderBy('web_industry_id')->get()->getResultArray();

foreach ($data as $i => &$row) {
    $row['serial_no'] = $i + 1;
}
unset($row);

$data_count = $this->db->table('web_industry')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

return $this->respond(
    data: $data,
    message: 'successfully',
    last_count: ($data_count['data_count'] ?? 1)
);
}

public function saveAboutOurIndustry()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }
    $db = \Config\Database::connect();
    $data = $this->request->getPost();
    $action = $data['for'] ?? '';
    $isNew  = ($data['web_industry_id'] == -1);
    $builder = $db->table('web_industry');

    // Handle Image Upload First
    $uploadedImage = null;
    $file = $this->request->getFile('web_image');
    if ($file && $file->isValid() && !$file->hasMoved()) {
        $uploadPath = ROOTPATH . 'images/industry/';
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0755, true);
        }
        $newName = 'industry_' . time() . '_' . rand(1000, 9999) . '.' . $file->getClientExtension();
        if ($file->move($uploadPath, $newName)) {
            $uploadedImage = $newName;
        } else {
            return $this->respond([], 'Failed to upload image', 500);
        }
    }

    switch ($action) {
        case 'delete':
            if (empty($data['web_industry_id'])) {
                return $this->respond([], 'ID required', 400);
            }

            $this->reorderDisplayOrder(
                table: 'web_industry',
                primaryKey: 'web_industry_id',
                currentId: $data['web_industry_id'],
                newOrder: 0,
                operation: 'delete'
            );

            $builder->where('web_industry_id', $data['web_industry_id'])
                    ->update(['is_deleted' => 1]);
            break;

        case 'status':
            if (empty($data['web_industry_id']) || !isset($data['is_active'])) {
                return $this->respond([], 'Invalid status', 400);
            }

            $builder->where('web_industry_id', $data['web_industry_id'])
                    ->update(['is_active' => $data['is_active'] ? 1 : 0]);
            break;

        case 'edit':
            // Required fields
            if (empty($data['web_title']) || !isset($data['display_order'])) {
                return $this->respond([], 'Title and Display Order are required', 400);
            }

            if ($isNew && !$uploadedImage) {
                return $this->respond([], 'Image is required when adding new item', 400);
            }

            $saveData = [
                'web_title'     => trim($data['web_title']),
                'display_order' => (int)$data['display_order'],
            ];

            // content is not required, but include it if present
            if (isset($data['web_content'])) {
                $saveData['web_content'] = $data['web_content'];
            }

            if ($uploadedImage) {
                $saveData['web_image'] = $uploadedImage;
            }

            if ($isNew) {
                // INSERT NEW
                $this->reorderDisplayOrder(
                    table: 'web_industry',
                    primaryKey: 'web_industry_id',
                    currentId: 0,
                    newOrder: $saveData['display_order'],
                    operation: 'insert'
                );

                $saveData['is_active']   = 1;
                $saveData['is_deleted']  = 0;
                $saveData['created_at']  = date('Y-m-d H:i:s');

                $builder->insert($saveData);
            } else {
                // UPDATE EXISTING
                $this->reorderDisplayOrder(
                    table: 'web_industry',
                    primaryKey: 'web_industry_id',
                    currentId: $data['web_industry_id'],
                    newOrder: $saveData['display_order'],
                    operation: 'update'
                );

                $saveData['updated_at'] = date('Y-m-d H:i:s');

                $builder->where('web_industry_id', $data['web_industry_id'])
                        ->update($saveData);
            }
            break;

        default:
            return $this->respond([], 'Invalid action', 400);
    }

    return $this->respond([], 'successfully');
}

// homepage how its works
public function pageServiceCate() {
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }
    $page['data'] = $this->db->table('web_content')
        ->select('*')
        ->where('web_content_id', 4)
        ->get()->getRowArray();
    $page['title'] = "How its works";
    $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>How its works</span></div>';
    return view('admin/pages/servicecate', $page);
}

public function getServiceCate() {
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }
    $data = $this->db->table('web_service_cate')
            ->select('web_service_cate_id,web_title,web_icon,web_content,display_order,created_on,display_order,is_active')
            ->where('is_deleted', 0);
    if ($this->request->getPost('web_service_cate_id', NULL)) {
        $data->where('web_service_cate_id', $this->request->getPost('web_service_cate_id', NULL));
    }
    $data = $data->orderBy('web_service_cate_id')
                    ->get()->getResultArray();

    foreach ($data as $i => &$row) {
        $row['serial_no'] = $i + 1;
    }
    unset($row);

    $data_count = $this->db->table('web_service_cate')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

    return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
}

public function saveServiceCate() {
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }
    $data = $this->request->getPost();

    // Check Mandatory Fielda
    switch ($data['for'] ?? '') {
        case "delete":
            $manda_arr = ['web_service_cate_id'];
            $allowedFields = ['is_deleted'];
            $this->reorderDisplayOrder(
                    table: 'web_service_cate',
                    primaryKey: 'web_service_cate_id',
                    currentId: $data['web_service_cate_id'],
                    newOrder: 0,
                    operation: 'delete',
            );
            break;

        case "status":
            $manda_arr = ['web_service_cate_id', 'is_active'];
            $allowedFields = ['is_active'];
            break;

        case "edit":
            $manda_arr = ['web_service_cate_id', 'web_title', 'web_icon', 'web_content',];
            $allowedFields = ['web_title', 'web_icon', 'web_content', 'display_order'];
            break;

        default:
            return $this->respond([], "Missing Data 'for'", 404);
    }

    $manda = checkMandatory($manda_arr, $data);
    if ($manda) {
        return $this->respond([], $manda, 404);
    }


    $updateData = array_intersect_key($data, array_flip($allowedFields));

    $builder = $this->db->table('web_service_cate');

    if ($data['web_service_cate_id'] > 0) {
        if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
            $this->reorderDisplayOrder(
                    table: 'web_service_cate',
                    primaryKey: 'web_service_cate_id',
                    currentId: $data['web_service_cate_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
            );
        }

        $updateData['updated_by'] = session()->get('user_login_id');
        $updateData['updated_on'] = date('Y-m-d H:i:s');
        $builder->where('web_service_cate_id', $data['web_service_cate_id']);
        if (!$builder->update($updateData)) {
            return $this->respond($data, 'Unable Update Data', 404);
        }
    } else {

        $this->reorderDisplayOrder(
                table: 'web_service_cate',
                primaryKey: 'web_service_cate_id',
                currentId: $data['web_service_cate_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
        );

        $updateData['created_by'] = session()->get('user_login_id');
        if (!$builder->insert($updateData)) {
            return $this->respond($data, 'Unable to save Data', 404);
        }
    }
    return $this->respond([], 'successfully');
}

// our products
public function pageClients()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

         $page['data'] = $this->db->table('web_content')
         ->select('*')
            ->where('web_content_id', 5)
            ->get()->getRowArray();

        $page['title'] = "Our Products";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home<i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Our Products</span></div>';
        
        return view('admin/pages/brand', $page);
    }

    public function getBrand()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_brand')
            ->select('web_brand_id,web_title,
            concat("' . BRAND_IMG . '",web_image) as web_image,display_order,created_on,display_order,is_active')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_brand_id', NULL)) {
            $data->where('web_brand_id', $this->request->getPost('web_brand_id', NULL));
        }
        $data = $data->orderBy('web_brand_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);

        $data_count = $this->db->table('web_brand')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveBrand()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_brand_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_brand',
                    primaryKey: 'web_brand_id',
                    currentId: $data['web_brand_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_brand_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "dashboard":
                $manda_arr = ['web_brand_id', 'is_dashboard'];
                $allowedFields = ['is_dashboard'];
                break;

            case "edit":
                $manda_arr = ['web_brand_id', 'web_title'];
                $allowedFields = ['web_title', 'is_dashboard', 'web_image', 'display_order'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/brand/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "project_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_brand_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_brand');

        if ($data['web_brand_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_brand',
                    primaryKey: 'web_brand_id',
                    currentId: $data['web_brand_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_brand_id', $data['web_brand_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_brand',
                primaryKey: 'web_brand_id',
                currentId: $data['web_brand_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }


// services 

public function pageApproach() {
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }
    $page['title'] = "Our Services";
    return view('admin/pages/services', $page);
}

public function getApproach() {
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }
    $data = $this->db->table('web_approach')
        ->select('web_approach_id,web_title,web_content,web_content_1,web_content_2,web_content_3,web_content_4,web_content_5,web_content_6,
            web_image,web_image_1,web_image_2,web_image,web_image_1,web_image_2,
            display_order,created_on,display_order,is_active')
        ->where('is_deleted', 0);

    if ($this->request->getPost('web_approach_id', NULL)) {
        $data->where('web_approach_id', $this->request->getPost('web_approach_id', NULL));
    }
    $data = $data->orderBy('web_approach_id')
                    ->get()->getResultArray();

    // Attach full image URLs if images are not null
    foreach ($data as $i => &$row) {
        $row['serial_no'] = $i + 1;
        if (!empty($row['web_image'])) {
            $row['web_image'] = base_url('images/approach/' . $row['web_image']);
        }
        if (!empty($row['web_image_1'])) {
            $row['web_image_1'] = base_url('images/approach/' . $row['web_image_1']);
        }
        if (!empty($row['web_image_2'])) {
            $row['web_image_2'] = base_url('images/approach/' . $row['web_image_2']);
        }
    }
    unset($row);

    $data_count = $this->db->table('web_approach')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

    return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
}

public function saveApproach() {
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }
    $data = $this->request->getPost();

    // Check Mandatory Fields
    switch ($data['for'] ?? '') {
        case "delete":
            $manda_arr = ['web_approach_id'];
            $allowedFields = ['is_deleted'];
            $this->reorderDisplayOrder(
                table: 'web_approach',
                primaryKey: 'web_approach_id',
                currentId: $data['web_approach_id'],
                newOrder: 0,
                operation: 'delete',
            );
            break;

        case "status":
            $manda_arr = ['web_approach_id', 'is_active'];
            $allowedFields = ['is_active'];
            break;

        case "edit":
            $manda_arr = [
                'web_approach_id', 'web_title', 'web_content', 'web_content_1',
                'web_content_2', 'web_content_3', 'web_content_4', 'web_content_5','web_content_6','display_order'
            ];
            $allowedFields = [
                'web_title', 'web_content', 'web_content_1', 'web_content_2', 'web_content_3',
                'web_content_4', 'web_content_5', 'web_content_6', 'web_image', 'web_image_1', 'web_image_2', 'display_order'
            ];

            // Decode all content fields if present
            for ($i = 0; $i <= 6; $i++) {
                $field = $i === 0 ? 'web_content' : 'web_content_' . $i;
                if (!empty($data[$field])) {
                    $data[$field] = html_entity_decode(
                        $data[$field],
                        ENT_QUOTES | ENT_HTML5,
                        'UTF-8'
                    );
                }
            }
            break;

        default:
            return $this->respond([], "Missing Data 'for'", 404);
    }

    $manda = checkMandatory($manda_arr, $data);
    if ($manda) {
        return $this->respond([], $manda, 404);
    }

    // Handle file uploads
    $fileMain = $this->request->getFile('web_image');
    $file1 = $this->request->getFile('web_image_1');
    $file2 = $this->request->getFile('web_image_2');

    $uploadPath = ROOTPATH . 'images/approach/';
    if (!is_dir($uploadPath)) {
        mkdir($uploadPath, 0755, true);
    }

    if ($fileMain && $fileMain->isValid() && !$fileMain->hasMoved()) {
        $newName = $fileMain->getRandomName();
        $fileMain->move($uploadPath, $newName);
        $data['web_image'] = $newName;
    }

    if ($file1 && $file1->isValid() && !$file1->hasMoved()) {
        $newName = $file1->getRandomName();
        $file1->move($uploadPath, $newName);
        $data['web_image_1'] = $newName;
    }

    if ($file2 && $file2->isValid() && !$file2->hasMoved()) {
        $newName = $file2->getRandomName();
        $file2->move($uploadPath, $newName);
        $data['web_image_2'] = $newName;
    }

    $updateData = array_intersect_key($data, array_flip($allowedFields));

    $builder = $this->db->table('web_approach');

    if ($data['web_approach_id'] > 0) {
        if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
            $this->reorderDisplayOrder(
                table: 'web_approach',
                primaryKey: 'web_approach_id',
                currentId: $data['web_approach_id'],
                newOrder: $data['display_order'],
                operation: 'update',
            );
        }

        $updateData['updated_by'] = session()->get('user_login_id');
        $updateData['updated_on'] = date('Y-m-d H:i:s');
        $builder->where('web_approach_id', $data['web_approach_id']);
        if (!$builder->update($updateData)) {
            return $this->respond($data, 'Unable Update Data', 404);
        }
    } else {

        $this->reorderDisplayOrder(
            table: 'web_approach',
            primaryKey: 'web_approach_id',
            currentId: $data['web_approach_id'],
            newOrder: $data['display_order'],
            operation: 'insert',
        );

        $updateData['created_by'] = session()->get('user_login_id');
        if (!$builder->insert($updateData)) {
            return $this->respond($data, 'Unable to save Data', 404);
        }
    }
    return $this->respond([], 'successfully');
}

public function pageProducts()
{
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    $page['title'] = "Products";
    $page['breadcrumb'] =
        '<div class="own-breadcrumb">
            Products<i class="fas fa-chevron-right"></i>
            <span>Products</span>
        </div>';

    return view('admin/pages/products', $page);
}

public function getEvent()
{
if (!session()->get('user_login_id')) {
    return $this->respond([], 'Session Expired', 404);
}

$builder = $this->db->table('web_event')
    ->select('
        *,
        concat("' . base_url(ADMIN_NAME) . '/product-manage/what-we-offer/", web_event_id) as image_url,
        concat("' . base_url(ADMIN_NAME) . '/product-manage/industry-appplications/", web_event_id) as video_url
    ')
    ->where('is_deleted', 0);

if ($this->request->getPost('web_event_id')) {
    $builder->where('web_event_id', $this->request->getPost('web_event_id'));
}

$data = $builder
    ->orderBy('display_order', 'ASC')
    ->get()
    ->getResultArray();

foreach ($data as $i => &$row) {
    $row['serial_no'] = $i + 1;
    $row['event_cover_url'] = $row['event_image']
        ? base_url('images/event/' . $row['event_image'])
        : '';
}
unset($row);

$count = $this->db->table('web_event')
    ->where('is_deleted', 0)
    ->countAllResults();

return $this->respond(
    data: $data,
    message: 'successfully',
    last_count: $count ?: 1
);
}


public function saveEvent()
{
if (!session()->get('user_login_id')) {
    return $this->respond([], 'Session Expired', 404);
}

$data = $this->request->getPost();

switch ($data['for'] ?? '') {

    // ---------- DELETE ----------
    case "delete":
        $manda_arr     = ['web_event_id'];
        $allowedFields = ['is_deleted'];

        $this->reorderDisplayOrder(
            table: 'web_event',
            primaryKey: 'web_event_id',
            currentId: $data['web_event_id'],
            newOrder: 0,
            operation: 'delete',
        );
        break;

    // ---------- STATUS ----------
    case "status":
        $manda_arr     = ['web_event_id', 'is_active'];
        $allowedFields = ['is_active'];
        break;

    // ---------- ADD / EDIT ----------
    case "edit":
        $manda_arr = [
            'web_event_id',
            'event_title',
            // 'event_date',
            'event_content',
            'display_order'
        ];

        $data['event_slug'] = slugify($data['event_title']);

        $allowedFields = [
            'event_title',
            'event_slug',
            // 'event_date',
            'event_content',
            'display_order',
            'is_active',
            'event_image'
        ];
        break;

    default:
        return $this->respond([], "Missing Data 'for'", 404);
}

// ---------- MANDATORY ----------
$manda = checkMandatory($manda_arr, $data);
if ($manda) {
    return $this->respond([], $manda, 404);
}

// ---------- IMAGE ----------
$file = $this->request->getFile('event_image');
if ($file && $file->isValid() && !$file->hasMoved()) {
    $path = ROOTPATH . 'images/event/';
    if (!is_dir($path)) mkdir($path, 0755, true);

    $newName = 'event_' . rand(100, 9999) . time() . '.' . $file->getExtension();
    $file->move($path, $newName);

    $data['event_image'] = $newName;
}
// Note: image is not mandatory anymore, so don't return error if not present

// ---------- FILTER ----------
$updateData = array_intersect_key($data, array_flip($allowedFields));
$builder    = $this->db->table('web_event');

// ---------- UPDATE ----------
if (!empty($data['web_event_id']) && (int)$data['web_event_id'] > 0) {

    if (!in_array($data['for'], ['delete', 'status'])) {
        $this->reorderDisplayOrder(
            table: 'web_event',
            primaryKey: 'web_event_id',
            currentId: $data['web_event_id'],
            newOrder: $data['display_order'],
            operation: 'update',
        );
    }

    $updateData['updated_by'] = session()->get('user_login_id');
    $updateData['updated_on'] = date('Y-m-d H:i:s');

    $builder->where('web_event_id', $data['web_event_id']);
    $builder->update($updateData);
}
// ---------- INSERT ----------
else {
    $this->reorderDisplayOrder(
        table: 'web_event',
        primaryKey: 'web_event_id',
        currentId: 0,
        newOrder: $data['display_order'],
        operation: 'insert',
    );

    $updateData['created_by'] = session()->get('user_login_id');
    $updateData['created_on'] = date('Y-m-d H:i:s');

    $builder->insert($updateData);
}

return $this->respond([], 'successfully');
}


public function pageImages($eventId)
{
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    $page['title']      = "What We Offer";
    $page['event_id']   = $eventId;
    $page['breadcrumb'] =
        '<div class="own-breadcrumb">
            Products <i class="fas fa-chevron-right"></i>
            <span>whatweoffer </span>
        </div>';

    return view('admin/pages/whatweoffer', $page);
}

// ---------------- GET ----------------
public function getEventImages()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }

    $eventId = $this->request->getPost('web_event_id');

    $data = $this->db->table('web_event_images')
        ->where('web_event_id', $eventId)
        ->where('is_deleted', 0)
        ->orderBy('display_order', 'ASC')
        ->get()
        ->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        
            // SAME STYLE AS TRIP GALLERY
            $row['image_url'] = base_url('images/event/' . $row['image_path']);
        }
        unset($row);
        

    return $this->respond(
        data: $data,
        message: 'successfully',
        last_count: count($data) ?: 1
    );
}

// ---------------- SAVE ----------------
public function saveEventImage()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }

    $data = $this->request->getPost();

    switch ($data['for'] ?? '') {

        // DELETE
        case "delete":
            $manda_arr     = ['image_id'];
            $allowedFields = ['is_deleted'];
            break;

        // STATUS
        case "status":
            $manda_arr     = ['image_id', 'is_active'];
            $allowedFields = ['is_active'];
            break;

        // ADD
        case "edit":
            $manda_arr     = ['web_event_id', 'display_order'];
            $allowedFields = [
                'web_event_id',
                'image_path',
                'web_title',
                'display_order',
                'is_active'
            ];
            break;

        default:
            return $this->respond([], "Missing Data 'for'", 404);
    }

    // Mandatory
    $manda = checkMandatory($manda_arr, $data);
    if ($manda) {
        return $this->respond([], $manda, 404);
    }

    // Upload image
    // Upload image
if (($data['for'] ?? '') === 'edit') {

$file = $this->request->getFile('image');
if (!$file || !$file->isValid()) {
    return $this->respond([], "Image Required", 404);
}

// SAME STYLE AS TRIP GALLERY
$uploadPath = ROOTPATH . 'images/event/';

if (!is_dir($uploadPath)) {
    mkdir($uploadPath, 0755, true);
}

$newName = 'event_' . time() . rand(100, 9999) . '.' . $file->getExtension();

if (!$file->move($uploadPath, $newName)) {
    return $this->respond([], "Unable to save Image", 404);
}

$data['image_path'] = $newName;
}

    

    $updateData = array_intersect_key($data, array_flip($allowedFields));
    $builder    = $this->db->table('web_event_images');

    // Insert
    if (($data['for'] ?? '') === 'edit') {
        $updateData['created_by'] = session()->get('user_login_id');
        $updateData['created_on'] = date('Y-m-d H:i:s');

        $builder->insert($updateData);
    }

    // Update (delete / status)
    else {
        $builder->where('image_id', $data['image_id']);
        $builder->update($updateData);
    }

    return $this->respond([], 'successfully');
}


public function pageVideos($eventId)
{
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    $page['title']    = "Industry Applications";
    $page['event_id'] = $eventId;
    $page['breadcrumb'] =
        '<div class="own-breadcrumb">
            Product<i class="fas fa-chevron-right"></i>
            <span>Industry Applications</span>
        </div>';

    return view('admin/pages/industryapplications', $page);
}

// ---------------- GET ----------------
public function getEventVideos()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }

    $eventId = $this->request->getPost('web_event_id');

    $data = $this->db->table('web_event_videos')
        ->where('web_event_id', $eventId)
        ->where('is_deleted', 0)
        ->orderBy('display_order', 'ASC')
        ->get()
        ->getResultArray();

    foreach ($data as $i => &$row) {
        $row['serial_no'] = $i + 1;
        $row['image_url'] = base_url('images/event/' . $row['video_url']);
    }
    unset($row);

    return $this->respond(
        data: $data,
        message: 'successfully',
        last_count: count($data) ?: 1
    );
}

// ---------------- SAVE ----------------
public function saveEventVideo()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }

    $data = $this->request->getPost();

    switch ($data['for'] ?? '') {

        // DELETE
        case "delete":
            $manda_arr     = ['video_id'];
            $allowedFields = ['is_deleted'];
            break;

        // STATUS
        case "status":
            $manda_arr     = ['video_id', 'is_active'];
            $allowedFields = ['is_active'];
            break;

        // ADD / EDIT
        case "edit":
            $manda_arr     = ['web_event_id', 'video_url', 'video_title', 'display_order'];
            $allowedFields = [
                'web_event_id',
                'video_url',
                'video_title',
                'display_order',
                'is_active'
            ];
            break;

        default:
            return $this->respond([], "Missing Data 'for'", 404);
    }

    // Mandatory
    $manda = checkMandatory($manda_arr, $data);
    if ($manda) {
        return $this->respond([], $manda, 404);
    }

    $updateData = array_intersect_key($data, array_flip($allowedFields));
    $builder    = $this->db->table('web_event_videos');

    // Insert
    if (($data['for'] ?? '') === 'edit') {
        $updateData['created_by'] = session()->get('user_login_id');
        $updateData['created_on'] = date('Y-m-d H:i:s');

        $builder->insert($updateData);
    }

    // Update (delete / status)
    else {
        $builder->where('video_id', $data['video_id']);
        $builder->update($updateData);
    }

    return $this->respond([], 'successfully');
}


    //Home Page Our Mission
    public function pageQuotes()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 1)
            ->get()
            ->getRowArray();
            
        $page['title'] = "Quotes";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i>
        <span>Quotes</span>
        </div>';

        return view('admin/pages/homequotes', $page);
    }



    
    


    //Home Page Take Action
    public function pageHomeTakeAction()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('* ,concat("' . CONTENT_IMG . '",web_image_1) as web_image,concat("' . CONTENT_IMG . '",web_image_2) as image2,
                            concat("' . CONTENT_IMG . '",web_image_3) as image3,concat("' . CONTENT_IMG . '",web_image_4) as web_image4')
            ->where('web_content_id', 4)
            ->get()->getRowArray();
        $page['title'] = "Reason Love us";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Reason Love us </span></div>';
        return view('admin/pages/homereason', $page);
    }

    //Home Page Founder message
    public function pageHomeFounder()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['richText'] = 1;

        $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
            ->where('web_content_id', 2)
            ->get()->getRowArray();

        $page['title'] = "Founder\'s Message";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Founder\'s Message</span></div>';
        return view('admin/pages/founder', $page);
    }

    //About Page Our Mission
    public function pageAboutOurMission()
{
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    $page['data'] = $this->db->table('web_content')
        ->select('*')
        ->where('web_content_id', 5)  // About Our Mission = ID 5
        ->get()
        ->getRowArray();

    $page['title'] = "About - Our Mission";
    $page['breadcrumb'] = '
        <div class="own-breadcrumb">
            About <i style="font-size:14px" class="fas fa-chevron-right"></i>
            <span>Our Mission</span>
        </div>';

    //  You can use a separate view if you want, e.g. 'aboutourmission'
    // or keep the same one if both use the same layout:
    return view('admin/pages/aboutmission', $page);
}


    //About Page TakeAction
    public function pageAboutDetails()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 8)
            ->get()->getRowArray();

        $page['title'] = "Details";
        $page['breadcrumb'] = '<div class="own-breadcrumb">About <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Details</span></div>';
        return view('admin/pages/aboutdetails', $page);
    }

    public function pageHomeOurWorks()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('* ,concat("' . CONTENT_IMG . '",web_image_1) as web_image,concat("' . CONTENT_IMG . '",web_image_2) as image2,
                            concat("' . CONTENT_IMG . '",web_image_3) as image3,concat("' . CONTENT_IMG . '",web_image_4) as web_image4')
            ->where('web_content_id', 35)
            ->get()->getRowArray();
        $page['title'] = "Home Our Works";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Our Works </span></div>';
        return view('admin/pages/homeourworks', $page);
    }

    //About Page Founder message
    public function pageAboutFounder()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['richText'] = 1;

        $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
            ->where('web_content_id', 7)
            ->get()->getRowArray();

        $page['title'] = "Founder\'s Message";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Founder\'s Message</span></div>';
        return view('admin/pages/founder', $page);
    }

    //Products Page message
    public function pageProductsContent()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 9)
            ->get()->getRowArray();

        $page['title'] = "Founder\'s Message";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Founder\'s Message</span></div>';
        return view('admin/pages/productscontent', $page);
    }

    public function pageProductsKitchen()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('* ,concat("' . CONTENT_IMG . '",web_image_1) as web_image,concat("' . CONTENT_IMG . '",web_image_2) as image2,
                            concat("' . CONTENT_IMG . '",web_image_3) as image3,concat("' . CONTENT_IMG . '",web_image_4) as web_image4,
                            concat("' . CONTENT_IMG . '",web_image_5) as web_image5')
            ->where('web_content_id', 30)
            ->get()->getRowArray();
        $page['title'] = "Product Models";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Products <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Models </span></div>';
        return view('admin/pages/productskitchen', $page);
    }
    public function pageProductsWall()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('* ,concat("' . CONTENT_IMG . '",web_image_1) as web_image,concat("' . CONTENT_IMG . '",web_image_2) as image2,
                            concat("' . CONTENT_IMG . '",web_image_3) as image3,concat("' . CONTENT_IMG . '",web_image_4) as web_image4,
                            concat("' . CONTENT_IMG . '",web_image_5) as web_image5')
            ->where('web_content_id', 31)
            ->get()->getRowArray();
        $page['title'] = "Product Models";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Products <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Models </span></div>';
        return view('admin/pages/productskitchen', $page);
    }
    public function pageProductsCeiling()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('* ,concat("' . CONTENT_IMG . '",web_image_1) as web_image,concat("' . CONTENT_IMG . '",web_image_2) as image2,
                            concat("' . CONTENT_IMG . '",web_image_3) as image3,concat("' . CONTENT_IMG . '",web_image_4) as web_image4,
                            concat("' . CONTENT_IMG . '",web_image_5) as web_image5')
            ->where('web_content_id', 32)
            ->get()->getRowArray();
        $page['title'] = "Product Models";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Products <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Models </span></div>';
        return view('admin/pages/productskitchen', $page);
    }
    public function pageProductsWooden()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('* ,concat("' . CONTENT_IMG . '",web_image_1) as web_image,concat("' . CONTENT_IMG . '",web_image_2) as image2,
                            concat("' . CONTENT_IMG . '",web_image_3) as image3,concat("' . CONTENT_IMG . '",web_image_4) as web_image4,
                            concat("' . CONTENT_IMG . '",web_image_5) as web_image5')
            ->where('web_content_id', 33)
            ->get()->getRowArray();
        $page['title'] = "Product Models";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Products <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Models </span></div>';
        return view('admin/pages/productskitchen', $page);
    }
    public function pageProductsArchitectural()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('* ,concat("' . CONTENT_IMG . '",web_image_1) as web_image,concat("' . CONTENT_IMG . '",web_image_2) as image2,
                            concat("' . CONTENT_IMG . '",web_image_3) as image3,concat("' . CONTENT_IMG . '",web_image_4) as web_image4,
                            concat("' . CONTENT_IMG . '",web_image_5) as web_image5')
            ->where('web_content_id', 34)
            ->get()->getRowArray();
        $page['title'] = "Product Models";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Products <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Models </span></div>';
        return view('admin/pages/productskitchen', $page);
    }

    //Brand
    public function pageConsultantContent()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['data'] = $this->db->table('web_content')
        ->select('*')
        ->where('web_content_id', 27)
        ->get()->getRowArray();
        $page['title'] = "ConsultantContent";
        return view('admin/pages/consultantcontent', $page);
    }
    public function pageConsultant()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        
        $page['title'] = "Consultant";
        return view('admin/pages/consultant', $page);
    }

    public function getConsultant()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_brand')
            ->select('web_brand_id,web_title,web_content,
            concat("' . CONSULTANT_IMG . '",web_image) as web_image,display_order,created_on,display_order,is_active')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_brand_id', NULL)) {
            $data->where('web_brand_id', $this->request->getPost('web_brand_id', NULL));
        }
        $data = $data->orderBy('web_brand_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);

        $data_count = $this->db->table('web_brand')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveConsultant()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_brand_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_brand',
                    primaryKey: 'web_brand_id',
                    currentId: $data['web_brand_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_brand_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "dashboard":
                $manda_arr = ['web_brand_id', 'is_dashboard'];
                $allowedFields = ['is_dashboard'];
                break;

            case "edit":
                $manda_arr = ['web_brand_id', 'web_title','web_content'];
                $allowedFields = ['web_title', 'is_dashboard', 'web_image','web_content', 'display_order'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/consultant/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "project_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_brand_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_brand');

        if ($data['web_brand_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_brand',
                    primaryKey: 'web_brand_id',
                    currentId: $data['web_brand_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_brand_id', $data['web_brand_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_brand',
                primaryKey: 'web_brand_id',
                currentId: $data['web_brand_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

    //Home Page Our Mission
    public function pageTeamClient()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 10)
            ->get()->getRowArray();

        $page['title'] = "Cilent";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Team <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Cilent</span></div>';
        return view('admin/pages/homequotes', $page);
    }

    //Get Home Page About
    public function pageHomeAbout()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
        ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image,concat("' . CONTENT_IMG . '",web_image_2) as image2,concat("' . CONTENT_IMG . '",web_image_3) as image3')
            ->where('web_content_id',6 )
            ->get()->getRowArray();
        log_message('error', print_r($page['data'], true));

        $page['title'] = "About";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>About</span></div>';
        return view('admin/pages/homeaboutcontent', $page);
    }

    //Resources Page
    public function pageConsultantcost()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['richText'] = true;

        $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '", web_image_1) as image')
            ->where('web_content_id', 29)
            ->get()->getRowArray();

        $page['title'] = "ConsultantCost";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Consultant<i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Cost</span></div>';
        return view('admin/pages/consultantcost', $page);
    }

    //Resources Page Gallery
    public function pageGallery()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 11)
            ->get()->getRowArray();
        $page['title'] = "Gallery";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Gallery<i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Gallery</span></div>';
        $page['gallerymaster'] = $this->db->table('web_content')
                            ->select('status')
                            ->where('web_content_id', 21)->get()->getRowArray();
        
        return view('admin/pages/gallery', $page);
    }

    public function getGallery()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_gallery')
            ->select('web_gallery_id,concat("' . GALLERY_IMG . '",web_image) as web_image,display_order,created_on,display_order,is_active')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_gallery_id', NULL)) {
            $data->where('web_gallery_id', $this->request->getPost('web_gallery_id', NULL));
        }
        $data = $data->orderBy('web_gallery_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);
        $data_count = $this->db->table('web_gallery')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveGallery()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_gallery_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_gallery',
                    primaryKey: 'web_gallery_id',
                    currentId: $data['web_gallery_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_gallery_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $manda_arr = ['web_gallery_id'];
                $allowedFields = ['web_title', 'web_image', 'display_order'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/gallery/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "gallery_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_gallery_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_gallery');

        if ($data['web_gallery_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_gallery',
                    primaryKey: 'web_gallery_id',
                    currentId: $data['web_gallery_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_gallery_id', $data['web_gallery_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_gallery',
                primaryKey: 'web_gallery_id',
                currentId: $data['web_gallery_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }


    //     public function saveGallerymaster()
    // {
    //     if (!session()->get('user_login_id')) {
    //         return $this->respond([], 'Session Expired', 404);
    //     }
    //        $data = $this->request->getPost();

    //       $web_content_id = $data['web_content_id'];
    //       $is_active = $data['is_active'];
    //           $page['data'] = $this->db->table('web_content')
    //             ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
    //             ->where('web_content_id',$web_content_id)
    //             ->get()->getRowArray();
    //             $builder = $this->db->table('web_content');
    
    //             $updateData['status'] = $is_active;
    //             $updateData['updated_by'] = session()->get('user_login_id');
    //             $updateData['updated_on'] = date('Y-m-d H:i:s');
    //             $builder->where('web_content_id', $web_content_id);
    //             if (!$builder->update($updateData)) {
    //              return $this->respond($data, 'Unable Update Data', 404);
    //             }
    //             return $this->respond([], 'successfully');

           

    // }



    //Resources Page Video
    public function pageVideo()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Video";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Resources <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Video</span></div>';
        $page['videomaster'] = $this->db->table('web_content')
                            ->select('status')
                            ->where('web_content_id', 22)->get()->getRowArray();
        
        return view('admin/pages/video', $page);
    }

    public function getVideo()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_video')
            ->select('web_video_id,web_title,web_name,web_url,display_order,created_on,display_order,is_active')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_video_id', NULL)) {
            $data->where('web_video_id', $this->request->getPost('web_video_id', NULL));
        }
        $data = $data->orderBy('web_video_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);
        $data_count = $this->db->table('web_video')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveVideo()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_video_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_video',
                    primaryKey: 'web_video_id',
                    currentId: $data['web_video_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_video_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $manda_arr = ['web_video_id'];
                $allowedFields = ['web_title', 'web_name', 'web_url', 'display_order'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_video');

        if ($data['web_video_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_video',
                    primaryKey: 'web_video_id',
                    currentId: $data['web_video_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_video_id', $data['web_video_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_video',
                primaryKey: 'web_video_id',
                currentId: $data['web_video_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }




    
           
   
    //Get Involved Page
    public function pageInvolved()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 11)
            ->get()->getRowArray();

        $page['title'] = "Involved";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Get Involved <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Content</span></div>';

            
        return view('admin/pages/homequotes', $page);
    }

    // Involved List
    public function pageInvolvedList()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Involved List";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Get Involved <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>List</span></div>';
        $page['involvemaster'] = $this->db->table('web_content')
                            ->select('status')
                            ->where('web_content_id', 23)->get()->getRowArray();
        
        return view('admin/pages/involvedlist', $page);
    }
    public function getDonationForm()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Donation Form";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Get Involved <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Donation Form</span></div>';  
        $page['donatemaster'] = $this->db->table('web_content')
                            ->select('status')
                            ->where('web_content_id', 25)->get()->getRowArray();
       
        return view('admin/pages/donationform', $page);
    }

    public function getInvolvedList()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_involved')
            ->select('web_involved_id,web_title,web_icon,web_content,display_order,created_on,display_order,is_active')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_involved_id', NULL)) {
            $data->where('web_involved_id', $this->request->getPost('web_involved_id', NULL));
        }
        $data = $data->orderBy('web_involved_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);

        $data_count = $this->db->table('web_involved')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveInvolvedList()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_involved_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_involved',
                    primaryKey: 'web_involved_id',
                    currentId: $data['web_involved_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_involved_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $manda_arr = ['web_involved_id', 'web_title', 'web_icon', 'web_content',];
                $allowedFields = ['web_title', 'web_icon', 'web_content', 'display_order'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_involved');

        if ($data['web_involved_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_involved',
                    primaryKey: 'web_involved_id',
                    currentId: $data['web_involved_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_involved_id', $data['web_involved_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_involved',
                primaryKey: 'web_involved_id',
                currentId: $data['web_involved_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }



    //Get Home Page About
    

    //Get Podcast Page content 
    public function pagePodcast()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 13)
            ->get()->getRowArray();

        $page['title'] = "Podcast";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Podcast <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Content</span></div>';

        
            
        
        return view('admin/pages/homequotes', $page);
    }

    public function saveContent()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();
          log_message('error',  print_r($data,true));
        $stats = $this->request->getPost('stats') ?? [];
        if ($stats) {
            if (!is_array($stats)) {
                $stats = []; // ensure it's always an array

            }
            $data['web_content_2'] = json_encode($stats, JSON_UNESCAPED_UNICODE);
        }
        $file = $this->request->getFile('web_file_1');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory
            $uploadPath = ROOTPATH . 'files/content/';

            // Ensure the directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            // Create a new file name
            $newName = "file_" . rand(1000, 9999) . time() . '.' . $file->getExtension();

            // Move the file
            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save file", 404);
            }

            // Save to the data array
            $data['web_file_1'] = $newName;
        }
    // If missionStatusHidden is posted, set status accordingly
    $missionStatus = $this->request->getPost('missionStatusHidden');
    if ($missionStatus !== null && $missionStatus !== '') {
        $data['status'] = $missionStatus;
    }


        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "edit":
                $manda_arr = [];
                $allowedFields = [
                    "web_content_1",
                    "web_content_2",
                    "web_content_3",
                    "web_content_4",
                    "web_content_5",
                    "web_content_6",
                    "web_content_7",
                    "web_content_8",
                    "web_content_9",
                    "web_content_10",
                    "web_content_11",
                    "web_content_12",
                    "web_content_13",
                    "web_content_14",
                    "web_content_15",
                    "web_content_16",
                    "web_content_17",
                    "web_content_18",
                    "web_content_19",
                    "web_content_20",
                    "web_content_21",
                    "web_content_22",
                    "web_content_23",
                    "web_content_24",
                    "web_content_25",
                    "web_content_26",
                    "web_content_27",
                    "web_content_28",
                    "web_content_29",
                    "web_content_30",
                    "web_content_31",
                    "web_content_32",
                    "web_content_33",
                    "web_content_34",
                    "web_content_35",
                    "web_content_36",
                    "web_content_37",
                    "web_file_1",
                    "web_image_1",
                    "web_image_2",
                    "web_image_3",
                    "web_image_4",
                    "web_image_5",
                    "status",
                ];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image_1');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/content/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "content_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image_1'] = $newName;
        }

        $file = $this->request->getFile('web_image_2');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/content/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "content_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image_2'] = $newName;
        }

        $file = $this->request->getFile('web_image_3');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/content/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "content_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image_3'] = $newName;
        }
        $file = $this->request->getFile('web_image_4');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/content/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "content_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image_4'] = $newName;
        }
        $file = $this->request->getFile('web_image_5');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/content/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "content_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image_5'] = $newName;
        }
        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_content');
        if ($data['web_content_id'] > 0) {
            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_content_id', $data['web_content_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {
            return $this->respond($data, 'Unable to save Data', 404);
        }
        return $this->respond([], 'successfully');
    }

    //podcast Page List
    public function pagePodcastList()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Podcast List";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Podcast <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>List</span></div>';
        $page['podcastvideomaster'] = $this->db->table('web_content')
                            ->select('status')
                            ->where('web_content_id', 24)->get()->getRowArray();
        return view('admin/pages/podcastlist', $page);
    }

    public function getPodcastList()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_podcast')
            ->select("web_podcast_id,web_title,web_desc,web_url,web_time,display_order,created_on,display_order,is_active,
                   DATE_FORMAT(web_time, '%d/%m/%Y %h:%i %p') AS web_time_formatted ")
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_podcast_id', NULL)) {
            $data->where('web_podcast_id', $this->request->getPost('web_podcast_id', NULL));
        }
        $data = $data->orderBy('web_podcast_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);
        $data_count = $this->db->table('web_podcast')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function savePodcastList()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_podcast_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_podcast',
                    primaryKey: 'web_podcast_id',
                    currentId: $data['web_podcast_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_podcast_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $manda_arr = ['web_podcast_id'];
                $allowedFields = ['web_title', 'web_desc', 'web_time', 'web_url', 'display_order'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        if (isset($data['web_time'])) {
            $date = $date = \DateTime::createFromFormat('d/m/Y h:i A', $data['web_time']);
            $data['web_time'] = $date->format('Y-m-d H:i:s');
        }


        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_podcast');

        if ($data['web_podcast_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_podcast',
                    primaryKey: 'web_podcast_id',
                    currentId: $data['web_podcast_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_podcast_id', $data['web_podcast_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_podcast',
                primaryKey: 'web_podcast_id',
                currentId: $data['web_podcast_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

    //Brand
    public function pageBlog()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Blog";
        $page['blogdatamaster'] = $this->db->table('web_content')
                            ->select('status')
                            ->where('web_content_id', 26)->get()->getRowArray();
        return view('admin/pages/blog', $page);
    }

    public function getBlog()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_blog')
            ->select('web_blog_id,web_title,web_cate_name,web_desc,
                    web_content,web_arthur_name,web_client_name,
                    web_client_desc,web_url,display_order,meta_title,meta_desc,meta_key,
                    is_active,concat("' . BLOG_IMG . '",web_image) as web_image,
                    concat("' . BLOG_IMG . '",web_image) as web_client_image,
                    DATE_FORMAT(web_time, "%d/%m/%Y") AS web_time')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_blog_id', NULL)) {
            $data->where('web_blog_id', $this->request->getPost('web_blog_id', NULL));
        }
        $data = $data->orderBy('web_blog_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);

        $data_count = $this->db->table('web_blog')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveBlog()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_blog_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_blog',
                    primaryKey: 'web_blog_id',
                    currentId: $data['web_blog_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_blog_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "dashboard":
                $manda_arr = ['web_blog_id', 'is_dashboard'];
                $allowedFields = ['is_dashboard'];
                break;

            case "edit":
                $data['web_url'] = slugify($data['web_title'] ?? '');
                $manda_arr = ['web_title', 'web_cate_name', 'web_desc', 'web_content', 'web_arthur_name', 'web_time', 'web_url', 'display_order'];
                $allowedFields = [
                    'web_title',
                    'web_cate_name',
                    'web_desc',
                    'web_content',
                    'web_arthur_name',
                    'web_image',
                    'web_client_name',
                    'web_client_desc',
                    'web_client_image',
                    'web_time',
                    'web_url',
                    'display_order',
                    'meta_title',
                    'meta_desc',
                    'meta_key'
                ];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/blog/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "blog_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_blog_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $file = $this->request->getFile('web_client_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/blog/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "blogauth_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_client_image'] = $newName;
        }

        if (isset($data['web_time'])) {
            $date = $date = \DateTime::createFromFormat('d/m/Y', $data['web_time']);
            $data['web_time'] = $date->format('Y-m-d H:i:s');
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_blog');

        if ($data['web_blog_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_blog',
                    primaryKey: 'web_blog_id',
                    currentId: $data['web_blog_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_blog_id', $data['web_blog_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_blog',
                primaryKey: 'web_blog_id',
                currentId: $data['web_blog_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

    public function upload_image()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }

        $file = $this->request->getFile('upload');

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $uploadPath = ROOTPATH . 'images/blog/';

            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            $newName = "ckeditor_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if ($file->move($uploadPath, $newName)) {
                return $this->respond([
                    'url' => base_url('images/blog/' . $newName)
                ]);
            }
        }

        return $this->respond([], "Unable to upload image", 404);
    }

    //Get Work with Us Page
    public function pageWorkUsContent()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 14)
            ->get()->getRowArray();

        $page['title'] = "Content";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Work with Us <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Content</span></div>';
        return view('admin/pages/homequotes', $page);
    }

    //Get Work with Us Page
    public function pagePilotPartner()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 15)
            ->get()->getRowArray();

        $page['title'] = "Pilot Partner";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Work with Us <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Pilot Partner</span></div>';
        return view('admin/pages/homequotes', $page);
    }

    //Get Work with Us Page
    public function pageWhatWeDo()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 16)
            ->get()->getRowArray();

        $page['title'] = "What We Do";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Work with Us <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>What We Do</span></div>';
        return view('admin/pages/whatwedo', $page);
    }
    //Get Work with Us Page
    public function pageMeasured()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 17)
            ->get()->getRowArray();

        $page['title'] = "Our Measured Impact";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Work with Us <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Our Measured Impact</span></div>';
        return view('admin/pages/measured', $page);
    }

    //we are work Page Banner
    public function pageSponser()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 18)
            ->get()->getRowArray();

        $page['title'] = "Sponser";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Work with Us <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Sponser</span></div>';
        return view('admin/pages/sponsor', $page);
    }

    public function getSponser()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_sponser')
            ->select('web_sponser_id,concat("' . SPONSER_IMG . '",web_image) as web_image,display_order,created_on,display_order,is_active')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_sponser_id', NULL)) {
            $data->where('web_sponser_id', $this->request->getPost('web_sponser_id', NULL));
        }
        $data = $data->orderBy('web_sponser_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);
        $data_count = $this->db->table('web_sponser')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveSponser()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_sponser_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_sponser',
                    primaryKey: 'web_sponser_id',
                    currentId: $data['web_sponser_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_sponser_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $manda_arr = ['web_sponser_id'];
                $allowedFields = ['web_title', 'web_image', 'display_order'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/sponser/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "sponser_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_sponser_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_sponser');

        if ($data['web_sponser_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_sponser',
                    primaryKey: 'web_sponser_id',
                    currentId: $data['web_sponser_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_sponser_id', $data['web_sponser_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_sponser',
                primaryKey: 'web_sponser_id',
                currentId: $data['web_sponser_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }


    //we are work Looks
    public function pageLooks()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['data'] = $this->db->table('web_content')
            ->select('*')
            ->where('web_content_id', 19)
            ->get()->getRowArray();

        $page['title'] = "Looks Like in Action";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Work with Us <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Looks Like in Action</span></div>';
        return view('admin/pages/looks', $page);
    }

    public function getLooks()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_looks')
            ->select('web_looks_id,web_title,web_content,web_content_page,concat("' . LOOKS_IMG . '",web_image) as web_image,'
                . 'display_order,created_on,display_order,is_active,meta_title,meta_desc,meta_key')
            ->where('is_deleted', 0);
        if ($this->request->getPost('web_looks_id', NULL)) {
            $data->where('web_looks_id', $this->request->getPost('web_looks_id', NULL));
        }
        $data = $data->orderBy('web_looks_id')
            ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);
        $data_count = $this->db->table('web_looks')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveLooks()
    {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_looks_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                    table: 'web_looks',
                    primaryKey: 'web_looks_id',
                    currentId: $data['web_looks_id'],
                    newOrder: 0,
                    operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_looks_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $data['web_url'] = slugify($data['web_title'] ?? '');
                $manda_arr = ['web_looks_id'];
                $allowedFields = ['web_title', 'web_content', 'web_content_page', 'web_image', 'web_url', 'display_order', 'meta_title', 'meta_desc', 'meta_key'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/looks/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "looks_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_looks_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_looks');

        if ($data['web_looks_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                    table: 'web_looks',
                    primaryKey: 'web_looks_id',
                    currentId: $data['web_looks_id'],
                    newOrder: $data['display_order'],
                    operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_looks_id', $data['web_looks_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                table: 'web_looks',
                primaryKey: 'web_looks_id',
                currentId: $data['web_looks_id'],
                newOrder: $data['display_order'],
                operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

    //Clients
    
    public function pageBono() 
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
            ->where('web_content_id', 3)
            ->get()->getRowArray();

        $page['title'] = "Bono";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Pro Bono Services <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Pro Bono Services</span></div>';
        return view('admin/pages/bonoservices', $page);
    }
    public function pageTeamFounder()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
            ->where('web_content_id', 4)
            ->get()->getRowArray();

        $page['title'] = "Founder\'s Message";
        $page['breadcrumb'] = '<div class="own-breadcrumb">About<i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Founder\'s Message</span></div>';
        return view('admin/pages/founder', $page);
    }

    public function pageAccomplishmentcontent()
    {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }

        $page['data'] = $this->db->table('web_content')
            ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image,concat("' . CONTENT_IMG . '",web_image_2) as image2,concat("' . CONTENT_IMG . '",web_image_3) as image3')
            ->where('web_content_id', 5)
            ->get()->getRowArray();

        $page['title'] = "Accomplishment";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Accomplishments <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Our Impact</span></div>';
        return view('admin/pages/accomplishmentcontent', $page);
    }

    
    //  Service

    public function pageService() {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Service";
        $page['breadcrumb'] = '<div class="own-breadcrumb">Services <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Services</span></div>';
        return view('admin/pages/service', $page);
    }

    public function getService() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_service')
                ->select('web_service_id,                   
            web_title,display_order,created_on,display_order,is_active')
                ->where('is_deleted', 0);
        if ($this->request->getPost('web_service_id', NULL)) {
            $data->where('web_service_id', $this->request->getPost('web_service_id', NULL));
        }
        $data = $data->orderBy('web_service_id')
                        ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
            $row['cate_btn'] = base_url(ADMIN_NAME . '/service-manage/' . $row['web_service_id']);
        }
        unset($row);

        $data_count = $this->db->table('web_service')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveService() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_service_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                        table: 'web_service',
                        primaryKey: 'web_service_id',
                        currentId: $data['web_service_id'],
                        newOrder: 0,
                        operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_service_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $data['web_url'] = slugify($data['web_title'] ?? '');
                $manda_arr = ['web_service_id', 'web_title'];
                $allowedFields = ['web_title', 'display_order', 'web_url'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_service');

        if ($data['web_service_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                        table: 'web_service',
                        primaryKey: 'web_service_id',
                        currentId: $data['web_service_id'],
                        newOrder: $data['display_order'],
                        operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_service_id', $data['web_service_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                    table: 'web_service',
                    primaryKey: 'web_service_id',
                    currentId: $data['web_service_id'],
                    newOrder: $data['display_order'],
                    operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }
    
public function getServiceNote()
{
    // Debug log
    log_message('error', 'Fetching first note from web_service_note table');

    // Get first row (oldest by ID)
    $data = $this->db->table('web_service_note')
        ->orderBy('web_service_note_id', 'ASC')
        ->get()
        ->getRowArray();

    // log_message('error', 'Note data: ' . print_r($note, true));

    // Always return a consistent JSON response
    return $this->respond([
        'code'    => 200,
        'message' => 'successfully',
        'data'    => $data ?? null
    ], 200);
}


public function saveServiceNote()
{
    if (!session()->get('user_login_id')) {
        return $this->respond([], 'Session Expired', 404);
    }

    $data = [
        'description' => $this->request->getPost('description2'),
    ];

    // Get the first row
    $firstRow = $this->db->table('web_service_note')
        ->orderBy('web_service_note_id', 'ASC')
        ->get()
        ->getRow();

    if ($firstRow) {
        // Update first row
        $this->db->table('web_service_note')
            ->where('web_service_note_id', $firstRow->web_service_note_id)
            ->update($data);
    } else {
        // Insert new row if table is empty
        $this->db->table('web_service_note')->insert($data);
    }

    return $this->respond(['code' => 200], 'successfully');
}


    //    Step 1 service

    public function pageServiceStep1($web_service_id) {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Service";
        $page['web_service_id'] = $web_service_id;

        $service = $this->db->table('web_service')
                        ->select('web_title')
                        ->where('is_deleted', 0)
                        ->where('web_service_id', $web_service_id)
                        ->get()->getRowArray();
        $page['service_name'] = $service['web_title'] ?? '';
        return view('admin/pages/service_step_1', $page);
    }

    public function getServiceStep1() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_service_step_1')
                ->select('web_service_step_1_id,web_service_id,web_title,is_next_level,web_content,
                        web_url,web_sub_title,web_cate_title_1,web_cate_content_1,web_cate_title_2,
                        web_cate_content_2,web_cate_title_3,web_cate_content_3,is_menu,footer_text,
                        concat("' . SERVICE_IMG . '",web_image) as web_image,concat("' . SERVICE_IMG . '",web_image_2) as web_image_2,concat("' . SERVICE_IMG . '",web_image_3) as web_image_3,display_order,created_on,display_order,is_active')
                ->where('is_deleted', 0)
                ->where('web_service_id', $this->request->getPost('web_service_id', NULL));
        if ($this->request->getPost('web_service_step_1_id', NULL)) {
            $data->where('web_service_step_1_id', $this->request->getPost('web_service_step_1_id', NULL));
        }
        $data = $data->orderBy('web_service_step_1_id')
                        ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
            $row['cate_btn'] = base_url(ADMIN_NAME . '/service-manage/' . $row['web_service_id'] . "/" . $row["web_service_step_1_id"]);
        }
        unset($row);

        $data_count = $this->db->table('web_service_step_1')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveServiceStep1() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fields
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_service_step_1_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                        table: 'web_service_step_1',
                        primaryKey: 'web_service_step_1_id',
                        currentId: $data['web_service_step_1_id'],
                        newOrder: 0,
                        operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_service_step_1_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $data['web_url'] = slugify($data['web_title'] ?? '');
                $manda_arr = ['web_service_step_1_id', 'web_title'];
                $allowedFields = [
                    'web_service_id', 'web_title', 'is_next_level', 'web_content',
                    'web_image', 'web_image_2', 'web_image_3', // Added new fields here
                    'web_url', 'web_sub_title', 'web_cate_title_1', 'web_cate_content_1', 
                    'web_cate_title_2', 'web_cate_content_2', 'web_cate_title_3', 
                    'web_cate_content_3', 'display_order'
                ];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }

        // Save web_image
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/service/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "service_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        }
        // Save web_image_2
        $file2 = $this->request->getFile('web_image_2');
        if ($file2 && $file2->isValid() && !$file2->hasMoved()) {
            $uploadPath = ROOTPATH . 'images/service/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName2 = "service2_" . rand(99, 9999) . time() . '.' . $file2->getExtension();

            if (!$file2->move($uploadPath, $newName2)) {
                return $this->respond([], "Unable to save Image 2", 404);
            }
            $data['web_image_2'] = $newName2;
        }
        // Save web_image_3
        $file3 = $this->request->getFile('web_image_3');
        if ($file3 && $file3->isValid() && !$file3->hasMoved()) {
            $uploadPath = ROOTPATH . 'images/service/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName3 = "service3_" . rand(99, 9999) . time() . '.' . $file3->getExtension();

            if (!$file3->move($uploadPath, $newName3)) {
                return $this->respond([], "Unable to save Image 3", 404);
            }
            $data['web_image_3'] = $newName3;
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $unset_value = [
            'web_content', 'web_image', 'web_image_2', 'web_image_3',
            'web_sub_title', 'web_cate_title_1', 'web_cate_content_1', 
            'web_cate_title_2', 'web_cate_content_2', 
            'web_cate_title_3', 'web_cate_content_3'
        ];
        if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
            if ($updateData['is_next_level'] != 1) {
                foreach ($unset_value as $use_unset) {
                    $updateData[$use_unset] = '';
                }
            }
        }
        $builder = $this->db->table('web_service_step_1');

        if ($data['web_service_step_1_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                        table: 'web_service_step_1',
                        primaryKey: 'web_service_step_1_id',
                        currentId: $data['web_service_step_1_id'],
                        newOrder: $data['display_order'],
                        operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_service_step_1_id', $data['web_service_step_1_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {
            $this->reorderDisplayOrder(
                    table: 'web_service_step_1',
                    primaryKey: 'web_service_step_1_id',
                    currentId: $data['web_service_step_1_id'],
                    newOrder: $data['display_order'],
                    operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

    //    Step 2 service

    public function pageServiceStep2($web_service_id, $web_service_step_1_id) {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Service";
        $page['web_service_id'] = $web_service_id;
        $page['web_service_step_1_id'] = $web_service_step_1_id;

        $service = $this->db->table('web_service')
                        ->select('web_title')
                        ->where('is_deleted', 0)
                        ->where('web_service_id', $web_service_id)
                        ->get()->getRowArray();
        $page['service_name'] = $service['web_title'] ?? '';

        $service = $this->db->table('web_service_step_1')
                        ->select('web_title')
                        ->where('is_deleted', 0)
                        ->where('web_service_step_1_id', $web_service_step_1_id)
                        ->get()->getRowArray();
        $page['step_1'] = $service['web_title'] ?? '';

        return view('admin/pages/service_step_2', $page);
    }

    public function getServiceStep2() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_service_step_2')
                ->select('web_service_step_1_id,web_service_step_2_id,web_service_id,web_title,is_next_level,web_content,
                        web_url,web_sub_title,web_cate_title_1,web_cate_content_1,web_cate_title_2,
                        web_cate_content_2,web_cate_title_3,web_cate_content_3,is_menu,footer_text,
                        concat("' . SERVICE_IMG . '",web_image) as web_image,display_order,created_on,display_order,is_active')
                ->where('is_deleted', 0)
                ->where('web_service_step_1_id', $this->request->getPost('web_service_step_1_id', NULL));
        if ($this->request->getPost('web_service_step_2_id', NULL)) {
            $data->where('web_service_step_2_id', $this->request->getPost('web_service_step_2_id', NULL));
        }
        $data = $data->orderBy('web_service_step_2_id')
                        ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
            $row['cate_btn'] = base_url(ADMIN_NAME . '/service-manage/' . $row['web_service_id'] . "/" . $row["web_service_step_1_id"] . "/" . $row["web_service_step_2_id"]);
        }
        unset($row);

        $data_count = $this->db->table('web_service_step_2')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveServiceStep2() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_service_step_2_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                        table: 'web_service_step_2',
                        primaryKey: 'web_service_step_2_id',
                        currentId: $data['web_service_step_2_id'],
                        newOrder: 0,
                        operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_service_step_2_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $data['web_url'] = slugify($data['web_title'] ?? '');
                $manda_arr = ['web_service_step_1_id', 'web_service_step_2_id', 'web_title','is_menu'];
                $allowedFields = ['web_service_step_1_id', 'web_service_id', 'web_title', 'is_next_level', 'web_content', 'web_image', 'web_url', 'web_sub_title', 'web_cate_title_1', 'web_cate_content_1', 'web_cate_title_2', 'web_cate_content_2', 'web_cate_title_3', 'web_cate_content_3', 'display_order','is_menu'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/service/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "service_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        }
//        else if ($data['web_service_step_2_id'] == -1) {
//            return $this->respond([], "Unable to save Image OR Missing Image", 404);
//        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $unset_value = ['web_content', 'web_image',  'web_sub_title', 'web_cate_title_1', 'web_cate_content_1', 'web_cate_title_2', 'web_cate_content_2', 'web_cate_title_3', 'web_cate_content_3'];
        if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
            if ($updateData['is_next_level'] != 1) {
                foreach ($unset_value as $use_unset) {
                    $updateData[$use_unset] = '';
                }
            }
        }
        $builder = $this->db->table('web_service_step_2');

        if ($data['web_service_step_2_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                        table: 'web_service_step_2',
                        primaryKey: 'web_service_step_2_id',
                        currentId: $data['web_service_step_2_id'],
                        newOrder: $data['display_order'],
                        operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_service_step_2_id', $data['web_service_step_2_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                    table: 'web_service_step_2',
                    primaryKey: 'web_service_step_2_id',
                    currentId: $data['web_service_step_2_id'],
                    newOrder: $data['display_order'],
                    operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

    //    Step 3 service

    public function pageServiceStep3($web_service_id, $web_service_step_1_id, $web_service_step_2_id) {
        if (!session()->get('user_login_id')) {
            return redirect()->to(base_url(ADMIN_NAME));
        }
        $page['title'] = "Service";
        $page['web_service_id'] = $web_service_id;
        $page['web_service_step_1_id'] = $web_service_step_1_id;
        $page['web_service_step_2_id'] = $web_service_step_2_id;

        $service = $this->db->table('web_service')
                        ->select('web_title')
                        ->where('is_deleted', 0)
                        ->where('web_service_id', $web_service_id)
                        ->get()->getRowArray();
        $page['service_name'] = $service['web_title'] ?? '';

        $service = $this->db->table('web_service_step_1')
                        ->select('web_title')
                        ->where('is_deleted', 0)
                        ->where('web_service_step_1_id', $web_service_step_1_id)
                        ->get()->getRowArray();
        $page['step_1'] = $service['web_title'] ?? '';

        $service = $this->db->table('web_service_step_2')
                        ->select('web_title')
                        ->where('is_deleted', 0)
                        ->where('web_service_step_2_id', $web_service_step_2_id)
                        ->get()->getRowArray();
        $page['step_2'] = $service['web_title'] ?? '';

        return view('admin/pages/service_step_3', $page);
    }

    public function getServiceStep3() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->db->table('web_service_step_3')
                ->select('web_service_step_1_id,web_service_step_2_id,web_service_step_3_id,web_service_id,web_title,web_content,
                        web_url,web_sub_title,web_cate_title_1,web_cate_content_1,web_cate_title_2,
                        web_cate_content_2,web_cate_title_3,web_cate_content_3,is_menu,footer_text,
                        concat("' . SERVICE_IMG . '",web_image) as web_image,display_order,created_on,display_order,is_active')
                ->where('is_deleted', 0)
                ->where('web_service_step_2_id', $this->request->getPost('web_service_step_2_id', NULL));
        if ($this->request->getPost('web_service_step_3_id', NULL)) {
            $data->where('web_service_step_3_id', $this->request->getPost('web_service_step_3_id', NULL));
        }
        $data = $data->orderBy('web_service_step_3_id')
                        ->get()->getResultArray();

        foreach ($data as $i => &$row) {
            $row['serial_no'] = $i + 1;
        }
        unset($row);

        $data_count = $this->db->table('web_service_step_3')->select('count(*) as data_count')->where('is_deleted', 0)->get()->getRowArray();

        return $this->respond(data: $data, message: 'successfully', last_count: ($data_count['data_count'] ?? 1));
    }

    public function saveServiceStep3() {
        if (!session()->get('user_login_id')) {
            return $this->respond([], 'Session Expired', 404);
        }
        $data = $this->request->getPost();

        // Check Mandatory Fielda
        switch ($data['for'] ?? '') {
            case "delete":
                $manda_arr = ['web_service_step_3_id'];
                $allowedFields = ['is_deleted'];
                $this->reorderDisplayOrder(
                        table: 'web_service_step_3',
                        primaryKey: 'web_service_step_3_id',
                        currentId: $data['web_service_step_3_id'],
                        newOrder: 0,
                        operation: 'delete',
                );
                break;

            case "status":
                $manda_arr = ['web_service_step_3_id', 'is_active'];
                $allowedFields = ['is_active'];
                break;

            case "edit":
                $data['web_url'] = slugify($data['web_title'] ?? '');
                $manda_arr = ['web_service_step_1_id', 'web_service_step_2_id', 'web_service_step_3_id', 'web_title', 'web_content','is_menu'];
                $allowedFields = ['web_service_step_1_id', 'web_service_step_2_id', 'web_service_id', 'web_title', 'web_content', 'web_image', 'web_url', 'web_sub_title', 'web_cate_title_1', 'web_cate_content_1', 'web_cate_title_2', 'web_cate_content_2', 'web_cate_title_3', 'web_cate_content_3', 'display_order','is_menu'];
                break;

            default:
                return $this->respond([], "Missing Data 'for'", 404);
        }

        $manda = checkMandatory($manda_arr, $data);
        if ($manda) {
            return $this->respond([], $manda, 404);
        }
        $file = $this->request->getFile('web_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Define the upload directory (root folder)
            $uploadPath = ROOTPATH . 'images/service/';

            // Ensure the upload directory exists
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = "service_" . rand(99, 9999) . time() . '.' . $file->getExtension();

            if (!$file->move($uploadPath, $newName)) {
                return $this->respond([], "Unable to save Image", 404);
            }
            $data['web_image'] = $newName;
        } else if ($data['web_service_step_3_id'] == -1) {
            return $this->respond([], "Unable to save Image OR Missing Image", 404);
        }

        $updateData = array_intersect_key($data, array_flip($allowedFields));

        $builder = $this->db->table('web_service_step_3');

        if ($data['web_service_step_3_id'] > 0) {
            if (!in_array(($data['for'] ?? ''), ["delete", "status"])) {
                $this->reorderDisplayOrder(
                        table: 'web_service_step_3',
                        primaryKey: 'web_service_step_3_id',
                        currentId: $data['web_service_step_3_id'],
                        newOrder: $data['display_order'],
                        operation: 'update',
                );
            }

            $updateData['updated_by'] = session()->get('user_login_id');
            $updateData['updated_on'] = date('Y-m-d H:i:s');
            $builder->where('web_service_step_3_id', $data['web_service_step_3_id']);
            if (!$builder->update($updateData)) {
                return $this->respond($data, 'Unable Update Data', 404);
            }
        } else {

            $this->reorderDisplayOrder(
                    table: 'web_service_step_3',
                    primaryKey: 'web_service_step_3_id',
                    currentId: $data['web_service_step_3_id'],
                    newOrder: $data['display_order'],
                    operation: 'insert',
            );

            $updateData['created_by'] = session()->get('user_login_id');
            if (!$builder->insert($updateData)) {
                return $this->respond($data, 'Unable to save Data', 404);
            }
        }
        return $this->respond([], 'successfully');
    }

    

//About Our Industry




public function pageWhoWeAre() {
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    $page['data'] = $this->db->table('web_content')
                    ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
                    ->where('web_content_id', 9)
                    ->get()->getRowArray();

    $page['title'] = "Achievements";
    $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Achievements</span></div>';
    return view('admin/pages/whoweare', $page);
}
  
    
    public function pageOurServices() {
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    $page['data'] = $this->db->table('web_content')
                    ->select('*,concat("' . CONTENT_IMG . '",web_image_1) as image')
                    ->where('web_content_id', 10)
                    ->get()->getRowArray();

    $page['title'] = "About Contact";
     $page['breadcrumb'] = '<div class="own-breadcrumb">About <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Call To Action</span></div>';
    return view('admin/pages/aboutcontact', $page);
}

public function pageAboveFooter() {
    if (!session()->get('user_login_id')) {
        return redirect()->to(base_url(ADMIN_NAME));
    }

    $page['data'] = $this->db->table('web_content')
                    ->select('*')
                    ->where('web_content_id', 11)
                    ->get()->getRowArray();

    $page['title'] = "Call to action";
    $page['breadcrumb'] = '<div class="own-breadcrumb">Home <i style="font-size:14px" class="fas fa-chevron-right"></i> <span>Call to action</span></div>';
    return view('admin/pages/homecontact', $page);
}
}
