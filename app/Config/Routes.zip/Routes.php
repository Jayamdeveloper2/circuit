<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->get('/', 'Home::index', ['as' => 'index']);

// Dynamic route alias fallback assignments
try {
    $db = \Config\Database::connect();
    $menus = $db->table('web_menu')->where('is_deleted', 0)->get()->getResultArray();
    foreach ($menus as $menu) {
        $slug = !empty($menu['web_url']) && $menu['web_url'] !== '0' ? $menu['web_url'] : null;
        
        // Final fallback if slug is missing 
        if (!$slug) {
            if ($menu['web_menu_id'] == 3) $slug = 'about';
            elseif ($menu['web_menu_id'] == 4) $slug = 'accomplishments';
            elseif ($menu['web_menu_id'] == 5) $slug = 'probono-services';
            elseif ($menu['web_menu_id'] == 2) $slug = 'services';
            elseif ($menu['web_menu_id'] == 6) $slug = 'contact';
        }

        if ($slug && $menu['web_menu_id'] != 1) {
            if ($menu['web_menu_id'] == 3) {
                $routes->get($slug, 'Home::pageAbout', ['as' => $slug]);
            } elseif ($menu['web_menu_id'] == 4) {
                $routes->get($slug, 'Home::pageaccomplishment', ['as' => $slug]);
            } elseif ($menu['web_menu_id'] == 5) {
                $routes->get($slug, 'Home::pageprobono', ['as' => $slug]);
            } elseif ($menu['web_menu_id'] == 2) {
                $routes->get($slug, 'Home::pageservices', ['as' => $slug]);
                $routes->get($slug . '/(:segment)', 'Home::pageServiceStep1/$1');
            } elseif ($menu['web_menu_id'] == 6) {
                $routes->get($slug, 'Home::pageContact', ['as' => $slug]);
            }
        }
    }
} catch (\Exception $e) {
    // Missing DB gracefully suppressed
}

$routes->post('contact/submit', 'Contact::submitContact');

// $routes->get('podcast', 'Home::pagePodcast', ['as' => 'podcast']);
// $routes->get('blog', 'Home::pageBlog', ['as' => 'blog']);
// $routes->get('blog/(:segment)', 'Home::pageBlogDetail/$1', ['as' => 'blog_detail']);
// $routes->get('work-with-us', 'Home::pageWorkWithUs', ['as' => 'work-with-us']);
// $routes->get('casestudy/(:segment)', 'Home::pageCaseStudyDetail/$1', ['as' => 'casestudy']);

try {
    $db = \Config\Database::connect();
    $menus = $db->table('web_menu')->where('is_deleted', 0)->get()->getResultArray();
    foreach ($menus as $menu) {
        $slug = !empty($menu['web_url']) && $menu['web_url'] !== '0' ? $menu['web_url'] : null;
        if ($slug && $menu['web_menu_id'] != 1) {
            if ($menu['web_menu_id'] == 3) {
                $routes->get($slug, 'Home::pageAbout');
            } elseif ($menu['web_menu_id'] == 4) {
                $routes->get($slug, 'Home::pageaccomplishment');
            } elseif ($menu['web_menu_id'] == 5) {
                $routes->get($slug, 'Home::pageprobono');
            } elseif ($menu['web_menu_id'] == 2) {
                $routes->get($slug, 'Home::pageservices');
                $routes->get($slug . '/(:segment)', 'Home::pageServiceStep1/$1');
            } elseif ($menu['web_menu_id'] == 6) {
                $routes->get($slug, 'Home::pageContact');
            }
        }
    }
} catch (\Exception $e) {
    // Missing DB gracefully suppressed
}

$routes->group(ADMIN_NAME, function ($routes) {
    $routes->get('/', 'Admin\Auth::index');

    $routes->get('logout', 'Admin\Auth::logout');
    $routes->post('upload-blog-content-image', 'Admin\Blog::upload_image');

    $routes->post('delete-blog-content-image', 'Admin\Blog::delete_image');

    //Menu    
    $routes->get('menu-manage', 'Admin\MainPage::pageMenu', ['as' => 'menu-manage']);

    //Setting
    $routes->get('social-manage', 'Admin\MainPage::pageSetting', ['as' => 'social-manage']);
    
    //SMTP Setting
    $routes->get('smtp-manage', 'Admin\MainPage::pageSmtp', ['as' => 'smtp-manage']);

    //Banner
    $routes->get('banner-manage', 'Admin\MainPage::pageBanner', ['as' => 'banner-manage']);

    //Home Meta
    $routes->get('home-meta', 'Admin\MainPage::pageHomeMeta', ['as' => 'home-meta']);

    //Home Page Our Mission
    $routes->get('homequotes-manage', 'Admin\MainPage::pageQuotes', ['as' => 'homequotes-manage']);
    

    //Home Page Take Action
    $routes->get('hometakeaction-manage', 'Admin\MainPage::pageHomeTakeAction', ['as' => 'hometakeaction-manage']);

    //Home Page Founder's message
    $routes->get('homefounder-manage', 'Admin\MainPage::pageHomeFounder', ['as' => 'homefounder-manage']);

    //Home Page About
    $routes->get('homeabout-manage', 'Admin\MainPage::pageHomeAbout', ['as' => 'homeabout-manage']);

    //Home our works
    $routes->get('homeour-manage', 'Admin\MainPage::pageHomeOurWorks', ['as' => 'homeour-manage']);

    //About Page Our Mission
    $routes->get('aboutourmission-manage', 'Admin\MainPage::pageAboutOurMission', ['as' => 'aboutourmission-manage']);

    //About Page Take Action
    $routes->get('aboutdetails-manage', 'Admin\MainPage::pageAboutDetails', ['as' => 'aboutdetails-manage']);

    //consultantcontent........
    
    //About Page Founder's message
    $routes->get('aboutfounder-manage', 'Admin\MainPage::pageAboutFounder', ['as' => 'aboutfounder-manage']);
    
    //Home Page About
    $routes->get('aboutabout-manage', 'Admin\MainPage::pageAboutAbout', ['as' => 'aboutabout-manage']);
    
    //Products Page message
    $routes->get('products-manage', 'Admin\MainPage::pageProductsContent', ['as' => 'products-manage']);

    //Products Kitchen
    $routes->get('products-kitchen', 'Admin\MainPage::pageProductsKitchen', ['as' => 'products-kitchen']);
    
    //Products Wall
    $routes->get('products-wall', 'Admin\MainPage::pageProductswall', ['as' => 'products-wall']);
    
    //Products Ceiling
    $routes->get('products-ceiling', 'Admin\MainPage::pageProductsCeiling', ['as' => 'products-ceiling']);
    
    //Products Wooden
    $routes->get('products-wooden', 'Admin\MainPage::pageProductsWooden', ['as' => 'products-wooden']);
    
    //Products Architectural
    $routes->get('products-architectural', 'Admin\MainPage::pageProductsArchitectural', ['as' => 'products-architectural']);
    
    //Products Page kitchen
    $routes->get('teamclient-manage', 'Admin\MainPage::pageTeamClient', ['as' => 'teamclient-manage']);
    
    //Technical Consultant Page
    // $routes->get('brand-manage', 'Admin\MainPage::pageConsultant', ['as' => 'brand-manage']);
    
    $routes->get('consultant-content', 'Admin\MainPage::pageConsultantContent', ['as' => 'consultant-content']);
    
    $routes->get('resources-manage', 'Admin\MainPage::pageConsultantCost', ['as' => 'resources-manage']);
    
    //Resources Gallery
    $routes->get('gallery-manage', 'Admin\MainPage::pageGallery', ['as' => 'gallery-manage']);

    //Resources Video
    $routes->get('video-manage', 'Admin\MainPage::pageVideo', ['as' => 'video-manage']);

    //Involved Page Resources
    $routes->get('involved-manage', 'Admin\MainPage::pageInvolved', ['as' => 'involved-manage']);

    //Involved Page List
    $routes->get('involvedlist-manage', 'Admin\MainPage::pageInvolvedList', ['as' => 'involvedlist-manage']);

    // Donation Form
    $routes->get('donation-form-manage', 'Admin\MainPage::getDonationForm', ['as' => 'donation-form-manage']);
    
    //Podcast Page content
    $routes->get('podcast-manage', 'Admin\MainPage::pagePodcast', ['as' => 'podcast-manage']);

    //Podcast page  List  
    $routes->get('podcastlist-manage', 'Admin\MainPage::pagePodcastList', ['as' => 'podcastlist-manage']);

    //blog page  List  
    $routes->get('blog-manage', 'Admin\MainPage::pageBlog', ['as' => 'blog-manage']);

    //Work with Us  content  
    $routes->get('work-content-manage', 'Admin\MainPage::pageWorkUsContent', ['as' => 'work-content-manage']);
    
    //Work with Us  contact  
    $routes->get('pilot-partner-manage', 'Admin\MainPage::pagePilotPartner', ['as' => 'pilot-partner-manage']);
    
     //Work with Us  Who we are  
    $routes->get('whatwedo-manage', 'Admin\MainPage::pageWhatWeDo', ['as' => 'whatwedo-manage']);
    
     //Work with Us  Our Measured Impact 
    $routes->get('measured-manage', 'Admin\MainPage::pageMeasured', ['as' => 'measured-manage']);
    
    //Work with Us  Sponser 
    $routes->get('sponsor-manage', 'Admin\MainPage::pageSponser', ['as' => 'sponsor-manage']);
    
    //Work with Us  Sponser 
    $routes->get('looks-manage', 'Admin\MainPage::pageLooks', ['as' => 'looks-manage']);

    //Clients
    $routes->get('clients-manage', 'Admin\MainPage::pageClients', ['as' => 'clients-manage']);

    $routes->get('Bonoservice-manage', 'Admin\MainPage::pageBono', ['as' => 'Bonoservice-manage']);

    $routes->get('teamfounder-manage', 'Admin\MainPage::pageTeamFounder', ['as' => 'teamfounder-manage']);

    $routes->get('our-impact', 'Admin\MainPage::pageAccomplishmentcontent', ['as' => 'our-impact']);

    // services
    $routes->get('service-manage', 'Admin\MainPage::pageService', ['as' => 'service-manage']);

    $routes->get('service-manage/(:segment)', 'Admin\MainPage::pageServiceStep1/$1');

    $routes->get('service-manage/(:segment)/(:segment)', 'Admin\MainPage::pageServiceStep2/$1/$2');

    $routes->get('service-manage/(:segment)/(:segment)/(:segment)', 'Admin\MainPage::pageServiceStep3/$1/$2/$3');
// our services
    $routes->get('ourservices-manage', 'Admin\MainPage::pageAboutOurBusiness', ['as' => 'ourservices-manage']);
//our industry
    $routes->get('ourindustry-manage','Admin\MainPage::pageAboutOurIndustry',['as'=>'ourindustry-manage']);

    $routes->get('how-its-works-manage', 'Admin\MainPage::pageServiceCate', ['as' => 'how-its-works-manage']);

    $routes->get('Achivements-manage', 'Admin\MainPage::pageWhoWeAre', ['as' => 'Achivements-manage']);
    
     $routes->get('services-manage', 'Admin\MainPage::pageApproach', ['as' => 'services-manage']);
     
     $routes->get('aboutcontact-manage', 'Admin\MainPage::pageOurServices', ['as' => 'aboutcontact-manage']);

    $routes->get('homecontact-manage', 'Admin\MainPage::pageAboveFooter', ['as' => 'homecontact-manage']);

    $routes->get('product-manage','Admin\MainPage::pageProducts',['as' => 'product-manage']);

    $routes->get('product-manage/what-we-offer/(:num)', 'Admin\MainPage::pageImages/$1');
    $routes->get('product-manage/industry-appplications/(:num)', 'Admin\MainPage::pageVideos/$1');

    $routes->group('api', function ($routes) {
        //Auth  
        $routes->post('loginCheck', 'Admin\Auth::loginCheck');
        $routes->post('changeUserPassword', 'Admin\Auth::changeUserPassword');
        $routes->post('changeUserEmail', 'Admin\Auth::changeUserEmail');

        //Menu
        $routes->post('getMenu', 'Admin\MainPage::getMenu');
        $routes->post('saveMenu', 'Admin\MainPage::saveMenu');

        //Setting
        $routes->post('saveSetting', 'Admin\MainPage::saveSetting');
        
        //SMTP Setting
        $routes->post('saveSmtp', 'Admin\MainPage::saveSmtp');

        //Home Meta
        $routes->post('saveHomeMeta', 'Admin\MainPage::saveHomeMeta');

        //Banner
        $routes->post('getBanner', 'Admin\MainPage::getBanner');
        $routes->post('saveBanner', 'Admin\MainPage::saveBanner');
        $routes->post('pagefunctionmanage', 'Admin\MainPage::pagefunctionmanage');

        //Brand
        // $routes->post('getBrand', 'Admin\MainPage::getConsultant');
        // $routes->post('saveBrand', 'Admin\MainPage::saveConsultant');

        //Involved Page List
        $routes->post('getInvolvedList', 'Admin\MainPage::getInvolvedList');
        $routes->post('saveInvolvedList', 'Admin\MainPage::saveInvolvedList');

        // Donation Form

        

        //Gallery List
        $routes->post('getGallery', 'Admin\MainPage::getGallery');
        $routes->post('saveGallery', 'Admin\MainPage::saveGallery');
        
        //Video List
        $routes->post('getVideo', 'Admin\MainPage::getVideo');
        $routes->post('saveVideo', 'Admin\MainPage::saveVideo');
        

        //Podcast List
        $routes->post('getPodcastList', 'Admin\MainPage::getPodcastList');
        $routes->post('savePodcastList', 'Admin\MainPage::savePodcastList');

        $routes->post('saveContent', 'Admin\MainPage::saveContent');

        //Blog
        $routes->post('getBlog', 'Admin\MainPage::getBlog');
        $routes->post('saveBlog', 'Admin\MainPage::saveBlog');
        
        //Sponser
        $routes->post('getSponser', 'Admin\MainPage::getSponser');
        $routes->post('saveSponser', 'Admin\MainPage::saveSponser');
        
        //Looks
        $routes->post('getLooks', 'Admin\MainPage::getLooks');
        $routes->post('saveLooks', 'Admin\MainPage::saveLooks');

        //Clients
        $routes->post('getBrand', 'Admin\MainPage::getBrand');
        $routes->post('saveBrand', 'Admin\MainPage::saveBrand');    

        //services

        $routes->post('getService', 'Admin\MainPage::getService');
        $routes->post('saveService', 'Admin\MainPage::saveService');

        $routes->post('getServiceStep1', 'Admin\MainPage::getServiceStep1');
        $routes->post('saveServiceStep1', 'Admin\MainPage::saveServiceStep1');

        $routes->post('getServiceStep2', 'Admin\MainPage::getServiceStep2');
        $routes->post('saveServiceStep2', 'Admin\MainPage::saveServiceStep2');

        $routes->post('getServiceStep3', 'Admin\MainPage::getServiceStep3');
        $routes->post('saveServiceStep3', 'Admin\MainPage::saveServiceStep3');

        $routes->post('getServiceNote', 'Admin\MainPage::getServiceNote');
        $routes->post('saveServiceNote', 'Admin\MainPage::saveServiceNote');

        $routes->post('getAboutOurBusiness', 'Admin\MainPage::getAboutOurBusiness');
        $routes->post('saveAboutOurBusiness', 'Admin\MainPage::saveAboutOurBusiness');

        $routes->post('getAboutOurIndustry','Admin\MainPage::getAboutOurIndustry');
        $routes->post('saveAboutOurIndustry','Admin\MainPage::saveAboutOurIndustry');

        $routes->post('getServiceCate', 'Admin\MainPage::getServiceCate');
        $routes->post('saveServiceCate', 'Admin\MainPage::saveServiceCate');
        
        $routes->post('getApproach', 'Admin\MainPage::getApproach');
        $routes->post('saveApproach', 'Admin\MainPage::saveApproach');


        $routes->post('getEvent', 'Admin\MainPage::getEvent');
        $routes->post('saveEvent', 'Admin\MainPage::saveEvent');


    
        $routes->post('getEventImages', 'Admin\MainPage::getEventImages');
        $routes->post('saveEventImage', 'Admin\MainPage::saveEventImage');

    
        $routes->post('getEventVideos', 'Admin\MainPage::getEventVideos');
        $routes->post('saveEventVideo', 'Admin\MainPage::saveEventVideo');

    });
});
